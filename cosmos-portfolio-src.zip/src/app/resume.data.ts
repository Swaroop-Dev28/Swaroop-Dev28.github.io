export const PROFILE = {
  name: 'Viswa Swaroop Naidu',
  role: 'Angular front-end developer',
  summary:
    'Five years of building and maintaining production applications: AngularJS interfaces wired to .NET Web APIs and SQL Server, with a habit of finding why a slow screen is slow and fixing it.',
  phone: '8919691718',
  email: 'swaroop.workmail@gmail.com',
  linkedin: 'https://linkedin.com/in/swaroop-naidu',
  whatsapp: 'https://wa.me/918919691718',
};

export interface Mission { role: string; place: string; years: string; project: string; points: string[]; }

export const MISSIONS: Mission[] = [
  {
    role: 'Angular Developer', place: 'Accenture', years: '2022 to 2026', project: 'mySP Integrated Project',
    points: [
      'Built and maintained AngularJS features in Visual Studio for a live production application.',
      'Sped up slow screens by removing unnecessary watchers, repeated digest cycles and heavy bindings.',
      'Connected AngularJS screens to .NET Web APIs and SQL Server; wrote the SQL in SSMS.',
      'Tested every API in Postman (response codes and payloads) before integrating it.',
      'Ran unit tests and cleared SonarQube findings: code smells, vulnerabilities, duplication.',
      'Worked with QA, backend and deployment teams to settle issues before releases.',
      'Covered for the team lead: daily scrum updates and blocker reports to management.',
    ],
  },
  {
    role: 'Android Developer (Fresher)', place: 'Accenture', years: '2021 to 2022', project: 'Shoppers Stop App',
    points: [
      'Fixed reported bugs in the Android app and kept JIRA tickets current within sprint timelines.',
      'Traced push notification failures using AppsFlyer logs.',
      'Investigated crashes with application logs and on-device debugging.',
      'Tested features across devices and Android versions before release.',
    ],
  },
];

export const SKILLS = [
  'AngularJS', 'UI performance', '.NET Web APIs', 'SQL Server', 'SSMS', 'Postman', 'Visual Studio', 'Git',
  'JIRA', 'SonarQube', 'Unit testing', 'Debugging', 'Android', 'AppsFlyer', 'Agile', 'Scrum',
];
